Orca remote project configuration

Prerequisites: Mac SSH alias, running devcontainer, unpacked Orca CLI at
/home/node/.config/orca-runtime/bin/orca-ide, Python 3 in all three environments,
and socat on the remote host and in the container. This package does not install
Orca, upgrade it, or copy authentication.

Edit ALIAS and CONTAINER at the top of install-project.py to match your setup.
The examples use the node user, /home/node/.config/orca-runtime, port 6768 in the
container and loopback tunnel port 16768. Adjust these together if needed.

On the Mac, from this directory:
  python3 install-project.py --check
  python3 install-project.py --apply
  python3 install-project.py --apply --reload-tunnel

Check is read-only (exit 2 means drift/inactive service/reload needed). Apply
backs up changed files and starts inactive services; it does not restart active
remote services. Reload-tunnel briefly reconnects the Mac client. Startup-script
changes take effect on the next ordinary server start. Keep the full skill
directory, including references/supervised.md.

Derived from the configuration checked on 2026-10-29 with Orca v1.4.243.
