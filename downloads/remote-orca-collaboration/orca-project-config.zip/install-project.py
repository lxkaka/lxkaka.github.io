#!/usr/bin/env python3
"""Check or install the project Orca configuration without restarting its server."""
import argparse
import datetime
import json
import os
from pathlib import Path
import plistlib
import shlex
import socket
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
ALIAS = 'project-host'
CONTAINER = 'project-a-devcontainer'
SSH = ['/usr/bin/ssh', '-T', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15',
       '-o', 'RemoteCommand=none', '-o', 'RequestTTY=no', ALIAS]
TUNNEL_ARGS = ['/usr/bin/ssh', '-N', '-T', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15',
               '-o', 'RemoteCommand=none', '-o', 'RequestTTY=no', '-o', 'ControlPath=none',
               '-o', 'ExitOnForwardFailure=yes', '-o', 'ServerAliveInterval=30',
               '-o', 'ServerAliveCountMax=3', '-L', '127.0.0.1:16768:127.0.0.1:16768', ALIAS]

SYNC = r'''
from pathlib import Path
import hashlib,json,os,tempfile
changes=[]
def sync(path,content,mode):
    path=Path(path); data=content.encode() if isinstance(content,str) else content
    if path.is_symlink(): raise RuntimeError('Refusing to replace symlink: '+str(path))
    old=path.read_bytes() if path.exists() else None
    if old==data and (path.stat().st_mode&0o777)==mode: return
    change={'path':str(path),'action':'update' if old is not None else 'create'}
    if apply:
        if old is not None:
            saved=backup/(hashlib.sha256(str(path).encode()).hexdigest()[:12]+'-'+path.name)
            saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(old);saved.chmod(0o600)
            change['backup']=str(saved)
        path.parent.mkdir(parents=True,exist_ok=True)
        fd,name=tempfile.mkstemp(prefix='.orca-install-',dir=path.parent)
        try:
            with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
            os.chmod(name,mode);os.replace(name,path)
        finally:Path(name).unlink(missing_ok=True)
    changes.append(change)
'''

CONTAINER_SCRIPT = r'''
import subprocess
root=Path('/home/node/.config/orca-runtime')
backup=root/'backups'/payload['stamp']
apply=payload['apply']
cli=root/'bin/orca-ide'
if not cli.exists(): raise RuntimeError('Install/unpack Orca first; runtime CLI is missing')
for rel,content in payload['files'].items():
    sync(root/rel,content,0o700 if rel.startswith('bin/') else 0o644)
for base in ['/home/node/.agents/skills','/home/node/.claude/skills']:
    link=Path(base)/'orca-peer-workflow';target=root/'skills/orca-peer-workflow'
    if link.is_symlink() and link.resolve()==target.resolve():continue
    if link.exists() or link.is_symlink():raise RuntimeError('Unexpected skill path: '+str(link))
    changes.append({'path':str(link),'action':'link'})
    if apply:link.parent.mkdir(parents=True,exist_ok=True);link.symlink_to(target,target_is_directory=True)
official=[Path(base)/'orca-cli/SKILL.md' for base in ['/home/node/.agents/skills','/home/node/.claude/skills']]
if any(not path.is_file() for path in official):
    changes.append({'paths':[str(path) for path in official if not path.is_file()],'action':'initialize-official-skill'})
    if apply:subprocess.run([str(cli),'skills','install','--skill','orca-cli','--agent','claude,codex','--json'],check=True,capture_output=True,text=True)
if apply:
    subprocess.run(['bash','-n',str(root/'bin/serve-project')],check=True,capture_output=True)
    import ast
    ast.parse((root/'bin/stop-project.py').read_text())
print(json.dumps({'changes':changes,'runtime':str(root)},ensure_ascii=False))
'''

HOST_SCRIPT = r"""
import subprocess,shlex
home=Path.home();state=home/'.local/state/orca-project'
backup=state/'backups'/payload['stamp'];apply=payload['apply'];container=payload['container']
inner='payload='+repr(payload)+'\n'+payload['sync']+'\n'+payload['container_script']
r=subprocess.run(['/usr/bin/docker','exec','-i','-u','node',container,'python3','-'],input=inner,capture_output=True,text=True,timeout=45)
if r.returncode:raise RuntimeError(r.stderr[-1500:])
container_result=json.loads(r.stdout)
server='''[Unit]
Description=Orca Server in project devcontainer
After=default.target

[Service]
Type=simple
ExecStart=/usr/bin/docker exec -u node @CONTAINER@ /home/node/.config/orca-runtime/bin/serve-project
ExecStop=/usr/bin/docker exec -u node @CONTAINER@ python3 /home/node/.config/orca-runtime/bin/stop-project.py
Restart=always
RestartSec=15
TimeoutStopSec=30
StandardOutput=append:@STATE@/server.log
StandardError=append:@STATE@/server.log

[Install]
WantedBy=default.target
'''.replace('@CONTAINER@',container).replace('@STATE@',str(state))
proxy_unit='''[Unit]
Description=Private loopback transport for project Orca
After=orca-project.service

[Service]
Type=simple
ExecStart=@STATE@/proxy.sh
Restart=always
RestartSec=10
StandardOutput=append:@STATE@/proxy.log
StandardError=append:@STATE@/proxy.log

[Install]
WantedBy=default.target
'''.replace('@STATE@',str(state))
sync(home/'.config/systemd/user/orca-project.service',server,0o600)
sync(home/'.config/systemd/user/orca-project-proxy.service',proxy_unit,0o600)
sync(state/'proxy.sh','#!/bin/bash\nset -euo pipefail\nexec /usr/bin/socat TCP4-LISTEN:16768,bind=127.0.0.1,reuseaddr,fork EXEC:'+str(state/'relay.sh')+',pipes\n',0o700)
sync(state/'relay.sh','#!/bin/bash\nset -euo pipefail\nexec /usr/bin/docker exec -i -u node '+shlex.quote(container)+' /usr/bin/socat STDIO TCP:127.0.0.1:6768\n',0o700)
if apply:
    state.mkdir(parents=True,exist_ok=True);state.chmod(0o700)
    for name in ['server.log','proxy.log']:
        p=state/name;p.touch(exist_ok=True);p.chmod(0o600)
    subprocess.run(['systemctl','--user','daemon-reload'],check=True,capture_output=True)
    subprocess.run(['systemctl','--user','enable','orca-project.service','orca-project-proxy.service'],check=True,capture_output=True)
states={}
for unit in ['orca-project.service','orca-project-proxy.service']:
    r=subprocess.run(['systemctl','--user','is-active',unit],capture_output=True,text=True)
    if apply and r.returncode:
        subprocess.run(['systemctl','--user','start',unit],check=True,capture_output=True)
        r=subprocess.run(['systemctl','--user','is-active',unit],capture_output=True,text=True)
    states[unit]=r.stdout.strip()
print(json.dumps({'container':container_result,'hostChanges':changes,'services':states},ensure_ascii=False))
"""


def tunnel_config(state):
    return {'Label': 'com.local.orca-project-tunnel', 'ProgramArguments': TUNNEL_ARGS,
            'RunAtLoad': True, 'KeepAlive': True, 'ThrottleInterval': 15,
            'StandardOutPath': str(state/'tunnel.out.log'),
            'StandardErrorPath': str(state/'tunnel.err.log')}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--apply', action='store_true')
    mode.add_argument('--check', action='store_true')
    parser.add_argument('--reload-tunnel', action='store_true', help='Apply the launchd update; briefly reconnects the Mac client')
    args = parser.parse_args()
    if args.reload_tunnel and not args.apply:
        parser.error('--reload-tunnel requires --apply')
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    files = {'bin/serve-project': (ROOT/'serve-project').read_text(),
             'bin/stop-project.py': (ROOT/'stop-project.py').read_text()}
    for p in (ROOT/'orca-peer-workflow').rglob('*'):
        if p.is_file():
            files['skills/orca-peer-workflow/'+str(p.relative_to(ROOT/'orca-peer-workflow'))] = p.read_text()
    payload = {'apply': args.apply, 'stamp': stamp, 'container': CONTAINER,
               'files': files, 'sync': SYNC, 'container_script': CONTAINER_SCRIPT}
    script = 'payload='+repr(payload)+'\n'+SYNC+'\n'+HOST_SCRIPT
    result = subprocess.run(SSH+['python3 -'], input=script, capture_output=True, text=True, timeout=80)
    if result.returncode:
        raise RuntimeError(result.stderr[-2000:])
    report = json.loads(result.stdout)
    state = Path.home()/'.local/state/orca-project'
    path = Path.home()/'Library/LaunchAgents/com.local.orca-project-tunnel.plist'
    desired = plistlib.dumps(tunnel_config(state))
    old = path.read_bytes() if path.exists() else None
    same = old is not None and plistlib.loads(old) == tunnel_config(state)
    mac_changed = not same
    rollback = state/'tunnel-reload-backup.plist'
    if args.apply:
        state.mkdir(parents=True, exist_ok=True);state.chmod(0o700)
        for name in ['tunnel.out.log', 'tunnel.err.log']:
            p=state/name;p.touch(exist_ok=True);p.chmod(0o600)
        if mac_changed:
            if old is not None:
                rollback.write_bytes(old);rollback.chmod(0o600)
                saved=state/'backups'/stamp/path.name;saved.parent.mkdir(parents=True,exist_ok=True)
                saved.write_bytes(old);saved.chmod(0o600)
            path.parent.mkdir(parents=True, exist_ok=True)
            fd,name=tempfile.mkstemp(prefix='.orca-install-',dir=path.parent)
            with os.fdopen(fd,'wb') as f:f.write(desired)
            os.chmod(name,0o600);os.replace(name,path)
        subprocess.run(['plutil','-lint',str(path)],check=True,capture_output=True)
    job='gui/'+str(os.getuid())+'/com.local.orca-project-tunnel'
    loaded=subprocess.run(['launchctl','print',job],capture_output=True,text=True)
    needs_reload=loaded.returncode!=0 or '\n\tprogram = /usr/bin/ssh\n' not in loaded.stdout
    if args.reload_tunnel and needs_reload:
        subprocess.run(['launchctl','bootout',job],capture_output=True)
        try:
            subprocess.run(['launchctl','bootstrap','gui/'+str(os.getuid()),str(path)],check=True,capture_output=True)
            deadline=time.monotonic()+20
            while True:
                try:
                    with socket.create_connection(('127.0.0.1',16768),timeout=1):break
                except OSError:
                    if time.monotonic()>=deadline:raise RuntimeError('New SSH tunnel did not become ready')
                    time.sleep(.25)
        except Exception:
            subprocess.run(['launchctl','bootout',job],capture_output=True)
            if rollback.exists():
                path.write_bytes(rollback.read_bytes());path.chmod(0o600)
                subprocess.run(['launchctl','bootstrap','gui/'+str(os.getuid()),str(path)],check=True,capture_output=True)
            raise
        needs_reload=False
    if args.apply and not needs_reload and (state/'tunnel.py').exists():
        saved=state/'backups'/stamp/'tunnel.py';saved.parent.mkdir(parents=True,exist_ok=True)
        (state/'tunnel.py').replace(saved)
    report['mac']={'configChanged':mac_changed,'reloadRequired':needs_reload,'directSSH':not needs_reload}
    drift=bool(report['container']['changes'] or report['hostChanges'] or mac_changed or needs_reload
               or any(state != 'active' for state in report['services'].values()))
    print(json.dumps(report,ensure_ascii=False,indent=2))
    if not args.apply and drift:return 2
    return 0


if __name__ == '__main__':
    sys.exit(main())
